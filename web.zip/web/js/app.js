    const toggleButton = document.getElementById('toggleSidebar');

if (toggleButton) {
    toggleButton.addEventListener('click', function () {
        document.body.classList.toggle('sidebar-collapsed');
    });
}
   function showPage(pageId, menuItem) {

    // إخفاء جميع الشاشات
    document.getElementById('dashboardPage').style.display = 'none';
    document.getElementById('studentsPage').style.display = 'none';
    document.getElementById('groupsPage').style.display = 'none';

    // إظهار الشاشة المطلوبة
    document.getElementById(pageId).style.display = 'block';

    // إزالة التحديد من القائمة
    document.querySelectorAll('.menu-item').forEach(function (item) {
        item.classList.remove('active');
    });

    // تحديد القسم الحالي
    menuItem.classList.add('active');

    // تغيير عنوان الشريط العلوي
    if (pageId === 'dashboardPage') {
        document.getElementById('pageTitle').textContent = 'الرئيسية';
        document.getElementById('pageSubtitle').textContent = 'لوحة التحكم';
    }

    else if (pageId === 'studentsPage') {
        document.getElementById('pageTitle').textContent = 'إدارة الطلاب';
        document.getElementById('pageSubtitle').textContent = 'عرض وإدارة بيانات الطلاب';
    }

    else if (pageId === 'groupsPage') {
        document.getElementById('pageTitle').textContent = 'إدارة المجموعات';
        document.getElementById('pageSubtitle').textContent = 'عرض وإدارة المجموعات ومواعيدها';
    }

}
// عناصر القوائم
// السنوات الدراسية حسب المرحلة
const schoolYears = {
    primary: [
        'الصف الأول الابتدائي',
        'الصف الثاني الابتدائي',
        'الصف الثالث الابتدائي',
        'الصف الرابع الابتدائي',
        'الصف الخامس الابتدائي',
        'الصف السادس الابتدائي'
    ],

    preparatory: [
        'الصف الأول الإعدادي',
        'الصف الثاني الإعدادي',
        'الصف الثالث الإعدادي'
    ],

    secondary: [
        'الصف الأول الثانوي',
        'الصف الثاني الثانوي',
        'الصف الثالث الثانوي'
    ]
};
const stageSelect = document.getElementById('studentStage');
const yearSelect = document.getElementById('studentYear');
const groupSelect = document.getElementById('studentGroup');

// عند تغيير المرحلة الدراسية
if (stageSelect && yearSelect && groupSelect) {

    stageSelect.addEventListener('change', function () {

    const selectedStage = this.value;

    // تصفير قائمة السنة
    yearSelect.innerHTML = '<option value="">اختر السنة الدراسية</option>';

    // تصفير قائمة المجموعة
    groupSelect.innerHTML = '<option value="">اختر المجموعة</option>';

    // إغلاق القائمتين مؤقتًا
    yearSelect.disabled = true;
    groupSelect.disabled = true;

    // إذا لم يتم اختيار مرحلة، نتوقف
    if (!selectedStage) {
        return;
    }

    // إضافة السنوات التابعة للمرحلة المختارة
    schoolYears[selectedStage].forEach(function (year, index) {

        const option = document.createElement('option');

        option.value = index + 1;
        option.textContent = year;

        yearSelect.appendChild(option);

    });

    // فتح قائمة السنوات
    yearSelect.disabled = false;

});
}
// قوائم المرحلة والسنة في نافذة إضافة المجموعة
const groupStageSelect = document.getElementById('groupStage');
const groupYearSelect = document.getElementById('groupYear');

// عند تغيير المرحلة الدراسية للمجموعة
if (groupStageSelect && groupYearSelect) {

    groupStageSelect.addEventListener('change', function () {
    const selectedStage = this.value;

    // تصفير قائمة السنة
    groupYearSelect.innerHTML =
        '<option value="">اختر السنة الدراسية</option>';

    groupYearSelect.disabled = true;

    // التوقف إذا لم يتم اختيار مرحلة
    if (!selectedStage) {
        return;
    }

    // إضافة السنوات التابعة للمرحلة
    schoolYears[selectedStage].forEach(function (year, index) {

        const option = document.createElement('option');

        option.value = index + 1;
        option.textContent = year;

        groupYearSelect.appendChild(option);

    });

    // تفعيل قائمة السنوات
    groupYearSelect.disabled = false;

});
}
// إضافة وحذف مواعيد المجموعة الأسبوعية
const groupSchedules = document.getElementById('groupSchedules');
const addScheduleBtn = document.getElementById('addScheduleBtn');

// إضافة موعد جديد
if (addScheduleBtn && groupSchedules) {

    addScheduleBtn.addEventListener('click', function () {

    const scheduleItem = document.createElement('div');

    scheduleItem.className = 'row g-3 align-items-end schedule-item mt-2';

    scheduleItem.innerHTML = `
        <div class="col-md-4">
            <label class="form-label">اليوم</label>
            <select class="form-select schedule-day">
                <option value="">اختر اليوم</option>
                <option value="saturday">السبت</option>
                <option value="sunday">الأحد</option>
                <option value="monday">الإثنين</option>
                <option value="tuesday">الثلاثاء</option>
                <option value="wednesday">الأربعاء</option>
                <option value="thursday">الخميس</option>
                <option value="friday">الجمعة</option>
            </select>
        </div>

        <div class="col-md-4">
            <label class="form-label">وقت بداية الحصة</label>
            <input type="time" class="form-control schedule-time">
        </div>

        <div class="col-md-3">
            <label class="form-label">مدة الحصة</label>
            <select class="form-select schedule-duration">
                <option value="">اختر المدة</option>
                <option value="60">60 دقيقة</option>
                <option value="90">90 دقيقة</option>
                <option value="120">120 دقيقة</option>
                <option value="150">150 دقيقة</option>
                <option value="180">180 دقيقة</option>
            </select>
        </div>

        <div class="col-md-1">
            <button type="button"
                    class="btn btn-outline-danger delete-schedule"
                    title="حذف الموعد">
                <i class="bi bi-trash"></i>
            </button>
        </div>
    `;

    groupSchedules.appendChild(scheduleItem);

});
}
// حذف موعد
groupSchedules.addEventListener('click', function (e) {

    const deleteButton = e.target.closest('.delete-schedule');

    if (deleteButton) {

        const schedules = groupSchedules.querySelectorAll('.schedule-item');

        if (schedules.length === 1) {
            alert('يجب الاحتفاظ بموعد واحد على الأقل.');
            return;
        }

        deleteButton.closest('.schedule-item').remove();
    }

});
// تخزين المجموعات مؤقتًا أثناء تشغيل الصفحة
let groupsData = [];
// التحقق من بيانات المجموعة والمواعيد
const saveGroupBtn = document.getElementById('saveGroupBtn');

if (saveGroupBtn) {

    saveGroupBtn.addEventListener('click', function () {

    const groupName = document.getElementById('groupName').value.trim();
    const groupStage = document.getElementById('groupStage').value;
    const groupYear = document.getElementById('groupYear').value;

    // التحقق من البيانات الأساسية
    if (!groupName || !groupStage || !groupYear) {
        alert('من فضلك أكمل اسم المجموعة والمرحلة والسنة الدراسية.');
        return;
    }

    // تجهيز بيانات المجموعة
    const newGroup = {
        name: groupName,
        stage: groupStage,
        year: groupYear,
        capacity: document.getElementById('groupCapacity').value,
        schedules: []
    };

    const schedules = groupSchedules.querySelectorAll('.schedule-item');
    const selectedDays = [];

    // التحقق من كل موعد وتجميعه
    for (let i = 0; i < schedules.length; i++) {

        const day = schedules[i].querySelector('.schedule-day').value;
        const time = schedules[i].querySelector('.schedule-time').value;
        const duration = schedules[i].querySelector('.schedule-duration').value;

        if (!day || !time || !duration) {
            alert('من فضلك أكمل اليوم ووقت البداية ومدة كل موعد.');
            return;
        }

        if (selectedDays.includes(day)) {
            alert('لا يمكن اختيار نفس اليوم أكثر من مرة.');
            return;
        }

        selectedDays.push(day);

        newGroup.schedules.push({
            day: day,
            time: time,
            duration: duration
        });
    }

    // حفظ المجموعة مؤقتًا
    groupsData.push(newGroup);

    console.log(groupsData);

    alert('تمت إضافة المجموعة بنجاح.');

const groupsTableBody = document.getElementById('groupsTableBody');

const groupCode = 'GR' + String(groupsData.length + 1).padStart(6, '0');

const dayNames = {
    saturday: 'السبت',
    sunday: 'الأحد',
    monday: 'الإثنين',
    tuesday: 'الثلاثاء',
    wednesday: 'الأربعاء',
    thursday: 'الخميس',
    friday: 'الجمعة'
};

function formatTime12(time) {
    const [hours, minutes] = time.split(':').map(Number);

    const period = hours >= 12 ? 'مساءً' : 'صباحًا';
    const hour12 = hours % 12 || 12;

    return `${hour12}:${String(minutes).padStart(2, '0')} ${period}`;
}

const schedulesText = newGroup.schedules.map(function (item) {
    return dayNames[item.day] + ' - ' + formatTime12(item.time);
}).join('<br>');
const row = document.createElement('tr');

row.innerHTML = `
    <td>${groupCode}</td>
    <td>${newGroup.name}</td>
    <td>${document.getElementById('groupStage').selectedOptions[0].text}</td>
<td>${document.getElementById('groupYear').selectedOptions[0].text}</td>
    <td>${schedulesText}</td>
    <td>0 / ${newGroup.capacity}</td>
    <td>
        <span class="badge bg-secondary">0%</span>
    </td>
    <td>
        <span class="badge bg-success">نشطة</span>
    </td>
    <td>
        <button class="btn btn-sm btn-outline-primary" title="عرض">
            <i class="bi bi-eye"></i>
        </button>
        <button class="btn btn-sm btn-outline-secondary" title="تعديل">
            <i class="bi bi-pencil"></i>
        </button>
    </td>
`;

groupsTableBody.appendChild(row);

});
}
// توحيد النصوص لتسهيل البحث باللغة العربية
function normalizeArabicSearch(text) {

    return text
        .toString()
        .trim()
        .toLowerCase()
        .replace(/[أإآ]/g, 'ا')
        .replace(/ى/g, 'ي')
        .replace(/ة/g, 'ه')
        .replace(/ـ/g, '')
        .replace(/[\u064B-\u065F\u0670]/g, '');

}
// تشغيل البحث في شاشة الطلاب
const studentSearch = document.getElementById('studentSearch');

studentSearch.addEventListener('input', function () {

    const searchValue = normalizeArabicSearch(this.value);

    const studentRows = document.querySelectorAll(
        '#studentsPage tbody tr'
    );

    studentRows.forEach(function (row) {

        const rowText = normalizeArabicSearch(row.textContent);

        if (rowText.includes(searchValue)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }

    });

});

