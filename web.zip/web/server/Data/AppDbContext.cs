
using Microsoft.EntityFrameworkCore;
using SmartTeacher.Api.Models;

namespace SmartTeacher.Api.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options)
        : base(options)
    {
    }

    // =========================
    // DbSets
    // =========================

    public DbSet<TeacherProfile> TeacherProfiles => Set<TeacherProfile>();
    public DbSet<AcademicYear> AcademicYears => Set<AcademicYear>();
    public DbSet<Stage> Stages => Set<Stage>();
    public DbSet<Grade> Grades => Set<Grade>();
    public DbSet<Student> Students => Set<Student>();
    public DbSet<StudentAcademicRecord> StudentAcademicRecords => Set<StudentAcademicRecord>();

    public DbSet<StudyGroup> StudyGroups => Set<StudyGroup>();
    public DbSet<GroupSchedule> GroupSchedules => Set<GroupSchedule>();
    public DbSet<StudentGroupEnrollment> StudentGroupEnrollments => Set<StudentGroupEnrollment>();
    public DbSet<LessonSession> LessonSessions => Set<LessonSession>();
    public DbSet<AttendanceRecord> AttendanceRecords => Set<AttendanceRecord>();
    public DbSet<AttendanceModificationLog> AttendanceModificationLogs => Set<AttendanceModificationLog>();

    public DbSet<StudentSubscription> StudentSubscriptions => Set<StudentSubscription>();
    public DbSet<StudentMonthlyDue> StudentMonthlyDues => Set<StudentMonthlyDue>();
    public DbSet<Payment> Payments => Set<Payment>();
    public DbSet<PaymentAllocation> PaymentAllocations => Set<PaymentAllocation>();
    public DbSet<StudentCreditTransaction> StudentCreditTransactions => Set<StudentCreditTransaction>();
    public DbSet<StudentCreditAllocation> StudentCreditAllocations => Set<StudentCreditAllocation>();
    public DbSet<StudentRefund> StudentRefunds => Set<StudentRefund>();

    public DbSet<CashBoxTransaction> CashBoxTransactions => Set<CashBoxTransaction>();
    public DbSet<Expense> Expenses => Set<Expense>();

    public DbSet<BookCategory> BookCategories => Set<BookCategory>();
    public DbSet<Book> Books => Set<Book>();
    public DbSet<BookSaleInvoice> BookSaleInvoices => Set<BookSaleInvoice>();
    public DbSet<BookSale> BookSales => Set<BookSale>();

    public DbSet<EvaluationType> EvaluationTypes => Set<EvaluationType>();
    public DbSet<Evaluation> Evaluations => Set<Evaluation>();
    public DbSet<EvaluationGroup> EvaluationGroups => Set<EvaluationGroup>();
    public DbSet<EvaluationGroupSchedule> EvaluationGroupSchedules => Set<EvaluationGroupSchedule>();
    public DbSet<StudentEvaluationResult> StudentEvaluationResults => Set<StudentEvaluationResult>();
    public DbSet<EvaluationResultModificationLog> EvaluationResultModificationLogs => Set<EvaluationResultModificationLog>();

    public DbSet<User> Users => Set<User>();
    public DbSet<Role> Roles => Set<Role>();
    public DbSet<Permission> Permissions => Set<Permission>();
    public DbSet<UserRole> UserRoles => Set<UserRole>();
    public DbSet<RolePermission> RolePermissions => Set<RolePermission>();

    public DbSet<StudentAccount> StudentAccounts => Set<StudentAccount>();
    public DbSet<StudentRegistrationRequest> StudentRegistrationRequests => Set<StudentRegistrationRequest>();
    public DbSet<StudentAccountLinkRequest> StudentAccountLinkRequests => Set<StudentAccountLinkRequest>();

    public DbSet<Announcement> Announcements => Set<Announcement>();
    public DbSet<AnnouncementTarget> AnnouncementTargets => Set<AnnouncementTarget>();
    public DbSet<Notification> Notifications => Set<Notification>();
    public DbSet<NotificationRecipient> NotificationRecipients => Set<NotificationRecipient>();

    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();
    public DbSet<BackupRecord> BackupRecords => Set<BackupRecord>();

    // =========================
    // Model Creating
    // =========================

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // Teacher Profile
        modelBuilder.Entity<TeacherProfile>(entity =>
        {
            entity.Property(x => x.TeacherName).HasMaxLength(150).IsRequired();
            entity.Property(x => x.SubjectName).HasMaxLength(150).IsRequired();
            entity.Property(x => x.CenterName).HasMaxLength(200);
            entity.Property(x => x.Phone).HasMaxLength(30);
            entity.Property(x => x.Address).HasMaxLength(300);
            entity.Property(x => x.LogoPath).HasMaxLength(500);
        });

        // Academic Year
        modelBuilder.Entity<AcademicYear>(entity =>
        {
            entity.Property(x => x.Name).HasMaxLength(50).IsRequired();
            entity.HasIndex(x => x.Name).IsUnique();
        });

        // Stage
        modelBuilder.Entity<Stage>(entity =>
        {
            entity.Property(x => x.StageName).HasMaxLength(100).IsRequired();
            entity.HasIndex(x => x.StageName).IsUnique();
        });

        // Grade
        modelBuilder.Entity<Grade>(entity =>
        {
            entity.Property(x => x.GradeName).HasMaxLength(100).IsRequired();

            entity.HasIndex(x => new { x.StageId, x.GradeName }).IsUnique();

            entity.HasOne(x => x.Stage)
                .WithMany(x => x.Grades)
                .HasForeignKey(x => x.StageId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        // Student
       modelBuilder.Entity<Student>(entity =>
{
    entity.Property(x => x.StudentCode).HasMaxLength(20).IsRequired();
    entity.HasIndex(x => x.StudentCode).IsUnique();

    entity.Property(x => x.FullName).HasMaxLength(200).IsRequired();
    entity.Property(x => x.Gender).HasMaxLength(10).IsRequired();
    entity.Property(x => x.StudentPhone).HasMaxLength(30).IsRequired();
    entity.Property(x => x.GuardianPhone).HasMaxLength(30).IsRequired();
    entity.Property(x => x.Address).HasMaxLength(300);
    entity.Property(x => x.Notes).HasMaxLength(1000);

    entity.ToTable(table =>
    {
        table.HasCheckConstraint(
            "CK_Student_Gender",
            "`Gender` IN ('Male', 'Female')");
    });
});

        // Student Academic Record
        modelBuilder.Entity<StudentAcademicRecord>(entity =>
        {
            entity.HasIndex(x => new { x.StudentId, x.AcademicYearId }).IsUnique();

            entity.HasOne(x => x.Student)
                .WithMany(x => x.AcademicRecords)
                .HasForeignKey(x => x.StudentId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(x => x.AcademicYear)
                .WithMany()
                .HasForeignKey(x => x.AcademicYearId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(x => x.Grade)
                .WithMany()
                .HasForeignKey(x => x.GradeId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        // Study Group
        modelBuilder.Entity<StudyGroup>(entity =>
{
    entity.Property(x => x.GroupName).HasMaxLength(100).IsRequired();

    entity.HasIndex(x => new
    {
        x.AcademicYearId,
        x.GradeId,
        x.GroupName
    }).IsUnique();

    entity.HasOne(x => x.AcademicYear)
        .WithMany()
        .HasForeignKey(x => x.AcademicYearId)
        .OnDelete(DeleteBehavior.Restrict);

    entity.HasOne(x => x.Grade)
        .WithMany()
        .HasForeignKey(x => x.GradeId)
        .OnDelete(DeleteBehavior.Restrict);
});// Group Schedule
       modelBuilder.Entity<GroupSchedule>(entity =>
{
    entity.HasOne(x => x.Group)
        .WithMany(x => x.Schedules)
        .HasForeignKey(x => x.GroupId)
        .OnDelete(DeleteBehavior.Restrict);

    entity.HasIndex(x => new
    {
        x.GroupId,
        x.DayOfWeek,
        x.StartTime
    }).IsUnique();

    entity.ToTable(table =>
    {
        table.HasCheckConstraint(
            "CK_GroupSchedule_DayOfWeek",
            "`DayOfWeek` BETWEEN 0 AND 6");

        table.HasCheckConstraint(
            "CK_GroupSchedule_DurationMinutes",
            "`DurationMinutes` IN (30, 60, 90, 120, 150)");
    });
});
        // Student Group Enrollment
        modelBuilder.Entity<StudentGroupEnrollment>(entity =>
        {
            entity.Property(x => x.Status).HasMaxLength(20).IsRequired();

            entity.HasOne(x => x.StudentAcademicRecord)
                .WithMany()
                .HasForeignKey(x => x.StudentAcademicRecordId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(x => x.Group)
                .WithMany()
                .HasForeignKey(x => x.GroupId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasIndex(x => new { x.StudentAcademicRecordId, x.StartDate });
        });

        // Lesson Session
       modelBuilder.Entity<LessonSession>(entity =>
{
    entity.Property(x => x.Status).HasMaxLength(20).IsRequired();
    entity.Property(x => x.Notes).HasMaxLength(1000);
    entity.Property(x => x.CancellationReason).HasMaxLength(500);

    entity.HasOne(x => x.Group)
        .WithMany()
        .HasForeignKey(x => x.GroupId)
        .OnDelete(DeleteBehavior.Restrict);

    entity.HasOne(x => x.GroupSchedule)
        .WithMany()
        .HasForeignKey(x => x.GroupScheduleId)
        .OnDelete(DeleteBehavior.Restrict);

    entity.HasOne(x => x.RescheduledToSession)
        .WithMany()
        .HasForeignKey(x => x.RescheduledToSessionId)
        .OnDelete(DeleteBehavior.Restrict);

    entity.HasIndex(x => new { x.GroupId, x.SessionDate });

    entity.HasIndex(x => x.RescheduledToSessionId);

    entity.ToTable(table =>
    {
        table.HasCheckConstraint(
            "CK_LessonSession_DurationMinutes",
            "`DurationMinutes` IN (30, 60, 90, 120, 150)");

        table.HasCheckConstraint(
            "CK_LessonSession_Status",
            "`Status` IN ('Upcoming', 'InProgress', 'Postponed', 'Cancelled', 'Completed')");

        
    });
});
        // Attendance Record
        modelBuilder.Entity<AttendanceRecord>(entity =>
{
    entity.Property(x => x.Status).HasMaxLength(20).IsRequired();
    entity.Property(x => x.RecordingMethod).HasMaxLength(20).IsRequired();
    entity.Property(x => x.Notes).HasMaxLength(1000);

    entity.HasIndex(x => new
    {
        x.LessonSessionId,
        x.StudentGroupEnrollmentId
    }).IsUnique();

    entity.HasOne(x => x.LessonSession)
        .WithMany()
        .HasForeignKey(x => x.LessonSessionId)
        .OnDelete(DeleteBehavior.Restrict);

    entity.HasOne(x => x.StudentGroupEnrollment)
        .WithMany()
        .HasForeignKey(x => x.StudentGroupEnrollmentId)
        .OnDelete(DeleteBehavior.Restrict);

    entity.ToTable(table =>
    {
        table.HasCheckConstraint(
            "CK_AttendanceRecord_Status",
            "`Status` IN ('Present', 'Absent', 'Excused')");

        table.HasCheckConstraint(
            "CK_AttendanceRecord_RecordingMethod",
            "`RecordingMethod` IN ('Barcode', 'Manual')");
    });
});
        // Attendance Modification Log
        modelBuilder.Entity<AttendanceModificationLog>(entity =>
{
    entity.Property(x => x.OldStatus).HasMaxLength(20).IsRequired();
    entity.Property(x => x.NewStatus).HasMaxLength(20).IsRequired();
    entity.Property(x => x.Reason).HasMaxLength(500);

    entity.HasOne(x => x.AttendanceRecord)
        .WithMany()
        .HasForeignKey(x => x.AttendanceRecordId)
        .OnDelete(DeleteBehavior.Restrict);

    entity.HasIndex(x => x.AttendanceRecordId);

    entity.ToTable(table =>
    {
        table.HasCheckConstraint(
            "CK_AttendanceModificationLog_OldStatus",
            "`OldStatus` IN ('Present', 'Absent', 'Excused')");

        table.HasCheckConstraint(
            "CK_AttendanceModificationLog_NewStatus",
            "`NewStatus` IN ('Present', 'Absent', 'Excused')");
    });
});
        // Student Subscription
        modelBuilder.Entity<StudentSubscription>(entity =>
        {
            entity.Property(x => x.MonthlyAmount).HasPrecision(10, 2);
            entity.Property(x => x.DiscountAmount).HasPrecision(10, 2);
            entity.Property(x => x.NetMonthlyAmount).HasPrecision(10, 2);
            entity.Property(x => x.Status).HasMaxLength(20).IsRequired();

            entity.HasOne(x => x.Enrollment)
                .WithMany()
                .HasForeignKey(x => x.EnrollmentId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasIndex(x => new { x.EnrollmentId, x.StartDate });
        });

        // Student Monthly Due
        modelBuilder.Entity<StudentMonthlyDue>(entity =>
        {
            entity.Property(x => x.SubscriptionAmount).HasPrecision(10, 2);
            entity.Property(x => x.DiscountAmount).HasPrecision(10, 2);
            entity.Property(x => x.DueAmount).HasPrecision(10, 2);

            entity.HasOne(x => x.Student)
                .WithMany()
                .HasForeignKey(x => x.StudentId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(x => x.AcademicYear)
                .WithMany()
                .HasForeignKey(x => x.AcademicYearId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(x => x.Enrollment)
                .WithMany()
                .HasForeignKey(x => x.EnrollmentId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(x => x.Subscription)
                .WithMany()
                .HasForeignKey(x => x.SubscriptionId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasIndex(x => new
            {
                x.StudentId,
                x.AcademicYearId,
                x.EnrollmentId,
                x.DueMonth
            }).IsUnique();
        });

        // Payment
        modelBuilder.Entity<Payment>(entity =>
        {
            entity.Property(x => x.Amount).HasPrecision(10, 2);
            entity.Property(x => x.PaymentMethod).HasMaxLength(30).IsRequired();
            entity.Property(x => x.ReceiptNumber).HasMaxLength(30).IsRequired();
            entity.Property(x => x.CancellationReason).HasMaxLength(500);

            entity.HasIndex(x => x.ReceiptNumber).IsUnique();

            entity.HasOne(x => x.Student)
                .WithMany()
                .HasForeignKey(x => x.StudentId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        // Payment Allocation
        modelBuilder.Entity<PaymentAllocation>(entity =>
        {
            entity.Property(x => x.AllocatedAmount).HasPrecision(10, 2);
            entity.Property(x => x.EntryType).HasMaxLength(20).IsRequired();

            entity.HasOne(x => x.Payment)
                .WithMany(x => x.Allocations)
                .HasForeignKey(x => x.PaymentId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(x => x.ReversesAllocation)
                .WithMany()
                .HasForeignKey(x => x.ReversesAllocationId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne<StudentMonthlyDue>()
                .WithMany()
                .HasForeignKey(x => x.DueId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne<BookSale>()
                .WithMany()
                .HasForeignKey(x => x.BookSaleId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasIndex(x => x.DueId);
            entity.HasIndex(x => x.BookSaleId);
        });

        // Student Credit Transaction
        modelBuilder.Entity<StudentCreditTransaction>(entity =>
        {
            entity.Property(x => x.TransactionType).HasMaxLength(20).IsRequired();
            entity.Property(x => x.Amount).HasPrecision(10, 2);
            entity.Property(x => x.Notes).HasMaxLength(500);

            entity.HasOne(x => x.Student)
                .WithMany()
                .HasForeignKey(x => x.StudentId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(x => x.Payment)
                .WithMany()
                .HasForeignKey(x => x.PaymentId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        // Student Credit Allocation
       modelBuilder.Entity<StudentCreditAllocation>(entity =>
{
    entity.Property(x => x.AllocatedAmount).HasPrecision(10, 2);

    entity.HasOne(x => x.CreditTransaction)
        .WithMany(x => x.Allocations)
        .HasForeignKey(x => x.CreditTransactionId)
        .OnDelete(DeleteBehavior.Restrict);

    entity.HasOne<StudentMonthlyDue>()
        .WithMany()
        .HasForeignKey(x => x.DueId)
        .OnDelete(DeleteBehavior.Restrict);

    entity.HasOne<BookSale>()
        .WithMany()
        .HasForeignKey(x => x.BookSaleId)
        .OnDelete(DeleteBehavior.Restrict);

    entity.HasIndex(x => x.DueId);
    entity.HasIndex(x => x.BookSaleId);
});

        // Student Refund
        modelBuilder.Entity<StudentRefund>(entity =>
{
    entity.Property(x => x.Amount).HasPrecision(10, 2);
    entity.Property(x => x.Reason).HasMaxLength(500);

    entity.HasOne(x => x.Student)
        .WithMany()
        .HasForeignKey(x => x.StudentId)
        .OnDelete(DeleteBehavior.Restrict);

    entity.HasOne(x => x.Payment)
        .WithMany()
        .HasForeignKey(x => x.PaymentId)
        .OnDelete(DeleteBehavior.Restrict);

    entity.HasOne(x => x.CreditTransaction)
        .WithMany()
        .HasForeignKey(x => x.CreditTransactionId)
        .OnDelete(DeleteBehavior.Restrict);

    entity.HasOne<StudentMonthlyDue>()
        .WithMany()
        .HasForeignKey(x => x.DueId)
        .OnDelete(DeleteBehavior.Restrict);

    entity.HasIndex(x => x.DueId);
});
        // Cash Box Transaction
        modelBuilder.Entity<CashBoxTransaction>(entity =>
        {
            entity.Property(x => x.TransactionType).HasMaxLength(30).IsRequired();
            entity.Property(x => x.SourceType).HasMaxLength(30).IsRequired();
            entity.Property(x => x.Amount).HasPrecision(10, 2);
            entity.Property(x => x.Description).HasMaxLength(500);

            entity.HasOne(x => x.ReversesTransaction)
                .WithMany()
                .HasForeignKey(x => x.ReversesTransactionId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        // Expense
        modelBuilder.Entity<Expense>(entity =>
        {
            entity.Property(x => x.ExpenseType).HasMaxLength(50).IsRequired();
            entity.Property(x => x.CustomExpenseName).HasMaxLength(150);
            entity.Property(x => x.Amount).HasPrecision(10, 2);
            entity.Property(x => x.Notes).HasMaxLength(1000);
        });

        // Book Category
       modelBuilder.Entity<BookCategory>(entity =>
{
    entity.Property(x => x.CategoryName).HasMaxLength(100).IsRequired();

    entity.HasIndex(x => x.CategoryName).IsUnique();
    entity.HasIndex(x => x.IsActive);
});

        // Book
      // Book
modelBuilder.Entity<Book>(entity =>
{
    entity.Property(x => x.BookName)
        .HasMaxLength(200)
        .IsRequired();

    entity.Property(x => x.PurchaseCost)
        .HasPrecision(10, 2);

    entity.Property(x => x.SellingPrice)
        .HasPrecision(10, 2);

    entity.HasOne(x => x.Category)
        .WithMany(x => x.Books)
        .HasForeignKey(x => x.CategoryId)
        .OnDelete(DeleteBehavior.Restrict);

    // منع الأسعار السالبة
    entity.ToTable(table =>
    {
        table.HasCheckConstraint(
            "CK_Books_PurchaseCost_NonNegative",
            "`PurchaseCost` >= 0");

        table.HasCheckConstraint(
            "CK_Books_SellingPrice_NonNegative",
            "`SellingPrice` >= 0");
    });
});

// Book Sale Invoice
modelBuilder.Entity<BookSaleInvoice>(entity =>
{
    entity.Property(x => x.InvoiceNumber)
        .HasMaxLength(30)
        .IsRequired();

    entity.HasIndex(x => x.InvoiceNumber).IsUnique();

    entity.Property(x => x.TotalAmount).HasPrecision(10, 2);
    entity.Property(x => x.Notes).HasMaxLength(500);

    entity.HasOne(x => x.Student)
        .WithMany()
        .HasForeignKey(x => x.StudentId)
        .OnDelete(DeleteBehavior.Restrict);
});
        // Book Sale
        modelBuilder.Entity<BookSale>(entity =>
        {
            entity.Property(x => x.PurchaseCost).HasPrecision(10, 2);
            entity.Property(x => x.SellingPrice).HasPrecision(10, 2);
            entity.Property(x => x.TotalAmount).HasPrecision(10, 2);
            entity.Property(x => x.TotalCost).HasPrecision(10, 2);

            entity.HasOne(x => x.Invoice)
                .WithMany(x => x.Items)
                .HasForeignKey(x => x.InvoiceId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(x => x.Book)
                .WithMany()
                .HasForeignKey(x => x.BookId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        // Evaluation Type
        modelBuilder.Entity<EvaluationType>(entity =>
        {
            entity.Property(x => x.TypeName).HasMaxLength(100).IsRequired();
            entity.HasIndex(x => x.TypeName).IsUnique();
        });

        // Evaluation
        modelBuilder.Entity<Evaluation>(entity =>
        {
            entity.Property(x => x.EvaluationName).HasMaxLength(200).IsRequired();
            entity.Property(x => x.CustomTypeName).HasMaxLength(100);
            entity.Property(x => x.MaxScore).HasPrecision(10, 2);
            entity.Property(x => x.CancellationReason).HasMaxLength(500);
            entity.Property(x => x.Notes).HasMaxLength(1000);

            entity.HasOne(x => x.AcademicYear)
                .WithMany()
                .HasForeignKey(x => x.AcademicYearId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(x => x.Grade)
                .WithMany()
                .HasForeignKey(x => x.GradeId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(x => x.EvaluationType)
                .WithMany(x => x.Evaluations)
                .HasForeignKey(x => x.EvaluationTypeId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        // Evaluation Group
        modelBuilder.Entity<EvaluationGroup>(entity =>
        {
            entity.HasIndex(x => new { x.EvaluationId, x.GroupId }).IsUnique();

            entity.HasOne(x => x.Evaluation)
                .WithMany()
                .HasForeignKey(x => x.EvaluationId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(x => x.Group)
                .WithMany()
                .HasForeignKey(x => x.GroupId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        // Evaluation Group Schedule
        modelBuilder.Entity<EvaluationGroupSchedule>(entity =>
        {
            entity.Property(x => x.Notes).HasMaxLength(500);

            entity.HasOne(x => x.EvaluationGroup)
                .WithMany(x => x.Schedules)
                .HasForeignKey(x => x.EvaluationGroupId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        // Student Evaluation Result
        modelBuilder.Entity<StudentEvaluationResult>(entity =>
        {
            entity.Property(x => x.Status).HasMaxLength(20).IsRequired();
            entity.Property(x => x.Score).HasPrecision(10, 2);
            entity.Property(x => x.Notes).HasMaxLength(1000);

            entity.HasIndex(x => new
            {
                x.EvaluationGroupId,
                x.StudentGroupEnrollmentId
            }).IsUnique();

            entity.HasOne(x => x.EvaluationGroup)
                .WithMany()
                .HasForeignKey(x => x.EvaluationGroupId)
                .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(x => x.StudentGroupEnrollment)
                .WithMany()
                .HasForeignKey(x => x.StudentGroupEnrollmentId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        // Evaluation Result Modification Log
        modelBuilder.Entity<EvaluationResultModificationLog>(entity =>
        {
            entity.Property(x => x.OldStatus).HasMaxLength(20).IsRequired();
            entity.Property(x => x.NewStatus).HasMaxLength(20).IsRequired();
            entity.Property(x => x.OldScore).HasPrecision(10, 2);
            entity.Property(x => x.NewScore).HasPrecision(10, 2);
            entity.Property(x => x.Reason).HasMaxLength(500);

            entity.HasOne(x => x.StudentEvaluationResult)
                .WithMany()
                .HasForeignKey(x => x.StudentEvaluationResultId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        // User
        modelBuilder.Entity<User>(entity =>
        {
            entity.Property(x => x.Username).HasMaxLength(100).IsRequired();
            entity.HasIndex(x => x.Username).IsUnique();

            entity.Property(x => x.PasswordHash).HasMaxLength(500).IsRequired();
            entity.Property(x => x.FullName).HasMaxLength(150).IsRequired();
            entity.Property(x => x.Phone).HasMaxLength(30);
        });

        // Role
        modelBuilder.Entity<Role>(entity =>
        {
            entity.Property(x => x.RoleName).HasMaxLength(100).IsRequired();
            entity.HasIndex(x => x.RoleName).IsUnique();
            entity.Property(x => x.Description).HasMaxLength(500);
        });

        // Permission
        modelBuilder.Entity<Permission>(entity =>
        {
            entity.Property(x => x.PermissionCode).HasMaxLength(100).IsRequired();
            entity.HasIndex(x => x.PermissionCode).IsUnique();

            entity.Property(x => x.PermissionName).HasMaxLength(150).IsRequired();
            entity.Property(x => x.Description).HasMaxLength(500);
        });

// User Audit Relationships
modelBuilder.Entity<AttendanceModificationLog>()
    .HasOne<User>()
    .WithMany()
    .HasForeignKey(x => x.ModifiedByUserId)
    .OnDelete(DeleteBehavior.Restrict);

modelBuilder.Entity<AttendanceRecord>()
    .HasOne<User>()
    .WithMany()
    .HasForeignKey(x => x.RecordedByUserId)
    .OnDelete(DeleteBehavior.Restrict);

modelBuilder.Entity<BackupRecord>()
    .HasOne<User>()
    .WithMany()
    .HasForeignKey(x => x.CreatedByUserId)
    .OnDelete(DeleteBehavior.Restrict);

modelBuilder.Entity<StudentAccountLinkRequest>()
    .HasOne<User>()
    .WithMany()
    .HasForeignKey(x => x.ReviewedByUserId)
    .OnDelete(DeleteBehavior.Restrict);

modelBuilder.Entity<StudentRegistrationRequest>()
    .HasOne<User>()
    .WithMany()
    .HasForeignKey(x => x.ReviewedByUserId)
    .OnDelete(DeleteBehavior.Restrict);

modelBuilder.Entity<CashBoxTransaction>()
    .HasOne<User>()
    .WithMany()
    .HasForeignKey(x => x.CreatedByUserId)
    .OnDelete(DeleteBehavior.Restrict);

modelBuilder.Entity<EvaluationResultModificationLog>()
    .HasOne<User>()
    .WithMany()
    .HasForeignKey(x => x.ModifiedByUserId)
    .OnDelete(DeleteBehavior.Restrict);

modelBuilder.Entity<Expense>()
    .HasOne<User>()
    .WithMany()
    .HasForeignKey(x => x.CreatedByUserId)
    .OnDelete(DeleteBehavior.Restrict);

modelBuilder.Entity<Payment>()
    .HasOne<User>()
    .WithMany()
    .HasForeignKey(x => x.ReceivedByUserId)
    .OnDelete(DeleteBehavior.Restrict);

modelBuilder.Entity<Payment>()
    .HasOne<User>()
    .WithMany()
    .HasForeignKey(x => x.CancelledByUserId)
    .OnDelete(DeleteBehavior.Restrict);

modelBuilder.Entity<StudentCreditTransaction>()
    .HasOne<User>()
    .WithMany()
    .HasForeignKey(x => x.CreatedByUserId)
    .OnDelete(DeleteBehavior.Restrict);

modelBuilder.Entity<StudentRefund>()
    .HasOne<User>()
    .WithMany()
    .HasForeignKey(x => x.CreatedByUserId)
    .OnDelete(DeleteBehavior.Restrict);

modelBuilder.Entity<Announcement>()
    .HasOne<User>()
    .WithMany()
    .HasForeignKey(x => x.CreatedByUserId)
    .OnDelete(DeleteBehavior.Restrict);

modelBuilder.Entity<AuditLog>()
    .HasOne<User>()
    .WithMany()
    .HasForeignKey(x => x.UserId)
    .OnDelete(DeleteBehavior.Restrict);
modelBuilder.Entity<BookSaleInvoice>()
    .HasOne<User>()
    .WithMany()
    .HasForeignKey(x => x.CreatedByUserId)
    .OnDelete(DeleteBehavior.Restrict);
        // User Role
       modelBuilder.Entity<UserRole>(entity =>
{
    entity.HasKey(x => new { x.UserId, x.RoleId });

    entity.HasOne(x => x.User)
        .WithMany(x => x.UserRoles)
        .HasForeignKey(x => x.UserId)
        .OnDelete(DeleteBehavior.Restrict);

    entity.HasOne(x => x.Role)
        .WithMany(x => x.UserRoles)
        .HasForeignKey(x => x.RoleId)
        .OnDelete(DeleteBehavior.Restrict);

    entity.HasIndex(x => x.RoleId);
});

        // Role Permission
       // Role Permission
modelBuilder.Entity<RolePermission>(entity =>
{
    entity.HasKey(x => new { x.RoleId, x.PermissionId });

    entity.HasOne(x => x.Role)
        .WithMany(x => x.RolePermissions)
        .HasForeignKey(x => x.RoleId)
        .OnDelete(DeleteBehavior.Restrict);

    entity.HasOne(x => x.Permission)
        .WithMany(x => x.RolePermissions)
        .HasForeignKey(x => x.PermissionId)
        .OnDelete(DeleteBehavior.Restrict);

    entity.HasIndex(x => x.PermissionId);
});

// Student Account
modelBuilder.Entity<StudentAccount>(entity =>
{
    entity.Property(x => x.Username).HasMaxLength(100).IsRequired();
    entity.HasIndex(x => x.Username).IsUnique();

    entity.Property(x => x.PasswordHash).HasMaxLength(500).IsRequired();
    entity.Property(x => x.Status).HasMaxLength(20).IsRequired();

    entity.HasIndex(x => x.StudentId).IsUnique();

    entity.HasOne(x => x.Student)
        .WithMany()
        .HasForeignKey(x => x.StudentId)
        .OnDelete(DeleteBehavior.Restrict);

    entity.ToTable(table =>
    {
        table.HasCheckConstraint(
            "CK_StudentAccount_Status",
            "`Status` IN ('Pending', 'Active', 'Disabled')");
    });
});
        // Student Registration Request
        modelBuilder.Entity<StudentRegistrationRequest>(entity =>
{
    entity.Property(x => x.FullName).HasMaxLength(200).IsRequired();
    entity.Property(x => x.Gender).HasMaxLength(10).IsRequired();
    entity.Property(x => x.StudentPhone).HasMaxLength(30).IsRequired();
    entity.Property(x => x.GuardianPhone).HasMaxLength(30).IsRequired();
    entity.Property(x => x.Address).HasMaxLength(300);
    entity.Property(x => x.Notes).HasMaxLength(1000);
    entity.Property(x => x.Status).HasMaxLength(20).IsRequired();
    entity.Property(x => x.ReviewNotes).HasMaxLength(500);

    entity.HasIndex(x => x.StudentAccountId).IsUnique();

    entity.HasOne(x => x.StudentAccount)
        .WithMany(x => x.RegistrationRequests)
        .HasForeignKey(x => x.StudentAccountId)
        .OnDelete(DeleteBehavior.Restrict);

    entity.ToTable(table =>
    {
        table.HasCheckConstraint(
            "CK_StudentRegistrationRequest_Status",
            "`Status` IN ('Pending', 'Approved', 'Rejected')");

        table.HasCheckConstraint(
            "CK_StudentRegistrationRequest_Gender",
            "`Gender` IN ('Male', 'Female')");
    });
});
        // Student Account Link Request
        modelBuilder.Entity<StudentAccountLinkRequest>(entity =>
{
    entity.Property(x => x.Status).HasMaxLength(20).IsRequired();
    entity.Property(x => x.ReviewNotes).HasMaxLength(500);

    entity.HasOne(x => x.StudentAccount)
        .WithMany()
        .HasForeignKey(x => x.StudentAccountId)
        .OnDelete(DeleteBehavior.Restrict);

    entity.HasOne(x => x.Student)
        .WithMany()
        .HasForeignKey(x => x.StudentId)
        .OnDelete(DeleteBehavior.Restrict);

    entity.HasIndex(x => new { x.StudentAccountId, x.SubmittedAt });

    entity.HasIndex(x => new { x.StudentAccountId, x.StudentId })
        .IsUnique();

    entity.ToTable(table =>
    {
        table.HasCheckConstraint(
            "CK_StudentAccountLinkRequest_Status",
            "`Status` IN ('Pending', 'Approved', 'Rejected')");
    });
});  // Announcement
        modelBuilder.Entity<Announcement>(entity =>
        {
            entity.Property(x => x.Title).HasMaxLength(200).IsRequired();
            entity.Property(x => x.Content).HasMaxLength(5000).IsRequired();
            entity.Property(x => x.Status).HasMaxLength(20).IsRequired();

            entity.HasMany(x => x.Targets)
                .WithOne(x => x.Announcement)
                .HasForeignKey(x => x.AnnouncementId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        // Announcement Target
        modelBuilder.Entity<AnnouncementTarget>(entity =>
        {
            entity.Property(x => x.TargetType).HasMaxLength(20).IsRequired();

            entity.HasIndex(x => new
            {
                x.AnnouncementId,
                x.TargetType,
                x.TargetId
            }).IsUnique();
        });

        // Notification
        modelBuilder.Entity<Notification>(entity =>
        {
            entity.Property(x => x.NotificationType).HasMaxLength(50).IsRequired();
            entity.Property(x => x.Title).HasMaxLength(200).IsRequired();
            entity.Property(x => x.Message).HasMaxLength(2000).IsRequired();
            entity.Property(x => x.RelatedEntityType).HasMaxLength(100);

            entity.HasMany(x => x.Recipients)
                .WithOne(x => x.Notification)
                .HasForeignKey(x => x.NotificationId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        // Notification Recipient
        modelBuilder.Entity<NotificationRecipient>(entity =>
        {
            entity.HasIndex(x => new
            {
                x.NotificationId,
                x.StudentAccountId
            }).IsUnique();

            entity.HasOne(x => x.StudentAccount)
                .WithMany()
                .HasForeignKey(x => x.StudentAccountId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        // Audit Log
       modelBuilder.Entity<AuditLog>(entity => 
        {
            entity.HasKey(x => x.Id);

            entity.Property(x => x.EntityType).HasMaxLength(100).IsRequired();
            entity.Property(x => x.EntityId).HasMaxLength(100).IsRequired();
            entity.Property(x => x.ActionType).HasMaxLength(50).IsRequired();
            entity.Property(x => x.OldValues).HasColumnType("longtext");
            entity.Property(x => x.NewValues).HasColumnType("longtext");
            entity.Property(x => x.Reason).HasMaxLength(1000);

            entity.HasIndex(x => new { x.EntityType, x.EntityId });
            entity.HasIndex(x => x.UserId);
            entity.HasIndex(x => x.CreatedAt);
        });

        // Backup Record
        modelBuilder.Entity<BackupRecord>(entity =>
{
    entity.Property(x => x.FileName).HasMaxLength(255).IsRequired();
    entity.HasIndex(x => x.FileName).IsUnique();

    entity.Property(x => x.FilePath).HasMaxLength(1000).IsRequired();
    entity.Property(x => x.BackupType).HasMaxLength(30).IsRequired();
    entity.Property(x => x.Checksum).HasMaxLength(64);
    entity.Property(x => x.Notes).HasMaxLength(1000);

    entity.HasIndex(x => x.CreatedAt);

    entity.ToTable(table =>
    {
        table.HasCheckConstraint(
            "CK_BackupRecord_BackupType",
            "`BackupType` IN ('Manual', 'BeforeRestore', 'External')");

        table.HasCheckConstraint(
            "CK_BackupRecord_FileSizeBytes",
            "`FileSizeBytes` >= 0");
    });
});
    }
}
