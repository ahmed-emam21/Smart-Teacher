namespace SmartTeacher.Api.Models;

public class Announcement
{
    public int Id { get; set; }

    public string Title { get; set; } = string.Empty;
    public string Content { get; set; } = string.Empty;

    // Draft / Scheduled / Published / Archived / Cancelled
    public string Status { get; set; } = "Draft";

    public DateTime? ScheduledAt { get; set; }
    public DateTime? PublishedAt { get; set; }
    public DateTime? ExpiresAt { get; set; }
    public DateTime? ArchivedAt { get; set; }

    public int? CreatedByUserId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public ICollection<AnnouncementTarget> Targets { get; set; }
        = new List<AnnouncementTarget>();
}