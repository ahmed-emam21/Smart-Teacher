namespace SmartTeacher.Api.Models;

public class AnnouncementTarget
{
    public int Id { get; set; }

    public int AnnouncementId { get; set; }

    // All / Group / Student
    public string TargetType { get; set; } = string.Empty;

    // فارغ عند اختيار All
    public int? TargetId { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public Announcement Announcement { get; set; } = null!;
}