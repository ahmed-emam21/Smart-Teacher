
namespace SmartTeacher.Api.Models;

public class AttendanceModificationLog
{
    public int Id { get; set; }

    public int AttendanceRecordId { get; set; }

    public string OldStatus { get; set; } = string.Empty;
    public string NewStatus { get; set; } = string.Empty;

    public DateTime? OldArrivalTime { get; set; }
    public DateTime? NewArrivalTime { get; set; }

    public string? Reason { get; set; }

    public int? ModifiedByUserId { get; set; }

    public DateTime ModifiedAt { get; set; } = DateTime.UtcNow;

    public AttendanceRecord AttendanceRecord { get; set; } = null!;
}
