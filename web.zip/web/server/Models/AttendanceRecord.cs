
namespace SmartTeacher.Api.Models;

public class AttendanceRecord
{
    public int Id { get; set; }

    public int LessonSessionId { get; set; }
    public int StudentGroupEnrollmentId { get; set; }

    // Present, Absent, Excused
    public string Status { get; set; } = "Present";

    public DateTime? ArrivalTime { get; set; }

    // Barcode or Manual
    public string RecordingMethod { get; set; } = "Manual";

    public string? Notes { get; set; }

    public int? RecordedByUserId { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }

    public LessonSession LessonSession { get; set; } = null!;
    public StudentGroupEnrollment StudentGroupEnrollment { get; set; } = null!;
}
