namespace SmartTeacher.Api.Models;

public class AuditLog
{
    public long Id { get; set; }

    public string EntityType { get; set; } = string.Empty;
    public string EntityId { get; set; } = string.Empty;

    // Create / Update / Delete / Approve / Reject / Cancel / Restore / Login
    public string ActionType { get; set; } = string.Empty;

    public string? OldValues { get; set; }
    public string? NewValues { get; set; }
    public string? Reason { get; set; }

    public int? UserId { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}