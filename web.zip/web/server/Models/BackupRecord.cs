namespace SmartTeacher.Api.Models;

public class BackupRecord
{
    public int Id { get; set; }

    public string FileName { get; set; } = string.Empty;
    public string FilePath { get; set; } = string.Empty;

    public long FileSizeBytes { get; set; }

    // Manual / BeforeRestore / External
    public string BackupType { get; set; } = "Manual";

    // SHA-256 للتحقق من سلامة الملف
    public string? Checksum { get; set; }

    public int? CreatedByUserId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public string? Notes { get; set; }
}