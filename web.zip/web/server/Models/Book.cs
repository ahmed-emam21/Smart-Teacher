namespace SmartTeacher.Api.Models;

public class Book
{
    public int Id { get; set; }

    public int CategoryId { get; set; }

    public string BookName { get; set; } = string.Empty;

    public decimal PurchaseCost { get; set; }
    public decimal SellingPrice { get; set; }

    public bool IsActive { get; set; } = true;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public BookCategory Category { get; set; } = null!;
}