namespace SmartTeacher.Api.Models;

public class BookCategory
{
    public int Id { get; set; }

    public string CategoryName { get; set; } = string.Empty;

    public bool IsActive { get; set; } = true;
    public bool IsDefault { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public ICollection<Book> Books { get; set; } = new List<Book>();
}