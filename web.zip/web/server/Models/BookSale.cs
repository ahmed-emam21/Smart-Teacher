namespace SmartTeacher.Api.Models;

public class BookSale
{
    public int Id { get; set; }

    public int InvoiceId { get; set; }
    public int BookId { get; set; }

    public int Quantity { get; set; }

    // Prices are snapshots at sale time
    public decimal PurchaseCost { get; set; }
    public decimal SellingPrice { get; set; }

    public decimal TotalAmount { get; set; }
    public decimal TotalCost { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public BookSaleInvoice Invoice { get; set; } = null!;
    public Book Book { get; set; } = null!;
}