namespace SmartTeacher.Api.Models;

public class BookSaleInvoice
{
    public int Id { get; set; }

    public int StudentId { get; set; }

    public string InvoiceNumber { get; set; } = string.Empty;

    public DateTime SaleDate { get; set; }

    public decimal TotalAmount { get; set; }

    public string? Notes { get; set; }

    public int? CreatedByUserId { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public Student Student { get; set; } = null!;

    public ICollection<BookSale> Items { get; set; } = new List<BookSale>();
}