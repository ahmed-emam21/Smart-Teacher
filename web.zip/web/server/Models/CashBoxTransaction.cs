namespace SmartTeacher.Api.Models;

public class CashBoxTransaction
{
    public int Id { get; set; }

    // Income, Expense, OpeningBalance, Reversal, StudentRefund
    public string TransactionType { get; set; } = string.Empty;

    // Payment, Expense, OpeningBalance, StudentRefund, Adjustment
    public string SourceType { get; set; } = string.Empty;

    public int? SourceId { get; set; }

    public decimal Amount { get; set; }

    public DateTime TransactionDate { get; set; }

    public string? Description { get; set; }

    public int? CreatedByUserId { get; set; }

    public int? ReversesTransactionId { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public CashBoxTransaction? ReversesTransaction { get; set; }
}