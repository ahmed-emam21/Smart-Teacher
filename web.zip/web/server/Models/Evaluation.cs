namespace SmartTeacher.Api.Models;

public class Evaluation
{
    public int Id { get; set; }
    public int AcademicYearId { get; set; }
    public int GradeId { get; set; }
    public int EvaluationTypeId { get; set; }

    public string EvaluationName { get; set; } = string.Empty;
    public string? CustomTypeName { get; set; }

    public decimal MaxScore { get; set; }
    public DateTime? GeneralDate { get; set; }

    public bool IsCancelled { get; set; }
    public DateTime? CancelledAt { get; set; }
    public string? CancellationReason { get; set; }
    public string? Notes { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public AcademicYear AcademicYear { get; set; } = null!;
    public Grade Grade { get; set; } = null!;
    public EvaluationType EvaluationType { get; set; } = null!;
}