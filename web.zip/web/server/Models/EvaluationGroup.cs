namespace SmartTeacher.Api.Models;

public class EvaluationGroup
{
    public int Id { get; set; }
    public int EvaluationId { get; set; }
    public int GroupId { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public Evaluation Evaluation { get; set; } = null!;
    public StudyGroup Group { get; set; } = null!;
    public ICollection<EvaluationGroupSchedule> Schedules { get; set; }
        = new List<EvaluationGroupSchedule>();
}