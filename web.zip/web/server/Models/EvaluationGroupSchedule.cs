namespace SmartTeacher.Api.Models;

public class EvaluationGroupSchedule
{
    public int Id { get; set; }
    public int EvaluationGroupId { get; set; }

    public DateTime ScheduledAt { get; set; }
    public string? Notes { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public EvaluationGroup EvaluationGroup { get; set; } = null!;
}