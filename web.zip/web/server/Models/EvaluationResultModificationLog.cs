namespace SmartTeacher.Api.Models;

public class EvaluationResultModificationLog
{
    public int Id { get; set; }

    public int StudentEvaluationResultId { get; set; }

    public string OldStatus { get; set; } = string.Empty;
    public string NewStatus { get; set; } = string.Empty;

    public decimal? OldScore { get; set; }
    public decimal? NewScore { get; set; }

    public string? Reason { get; set; }
    public int? ModifiedByUserId { get; set; }

    public DateTime ModifiedAt { get; set; } = DateTime.UtcNow;

    public StudentEvaluationResult StudentEvaluationResult { get; set; } = null!;
}