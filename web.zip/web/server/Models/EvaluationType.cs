namespace SmartTeacher.Api.Models;

public class EvaluationType
{
    public int Id { get; set; }
    public string TypeName { get; set; } = string.Empty;
    public bool IsDefault { get; set; }
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public ICollection<Evaluation> Evaluations { get; set; } = new List<Evaluation>();
}