namespace SmartTeacher.Api.Models;

public class Expense
{
    public int Id { get; set; }

    // Rent, Water, Electricity, Salaries,
    // OfficeSupplies, Other
    public string ExpenseType { get; set; } = string.Empty;

    public string? CustomExpenseName { get; set; }

    public decimal Amount { get; set; }

    public DateTime ExpenseDate { get; set; }

    public string? Notes { get; set; }

    public int? CreatedByUserId { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}