namespace SmartTeacher.Api.Models;

public class Grade
{
    public int Id { get; set; }

    public int StageId { get; set; }
    public string GradeName { get; set; } = string.Empty;

    public int SortOrder { get; set; }

    public bool IsActive { get; set; } = true;

    public Stage Stage { get; set; } = null!;
}