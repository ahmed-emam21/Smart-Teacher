
namespace SmartTeacher.Api.Models;

public class GroupSchedule
{
    public int Id { get; set; }

    public int GroupId { get; set; }

    // 0 = Sunday ... 6 = Saturday
    public int DayOfWeek { get; set; }

    public TimeSpan StartTime { get; set; }

    // 30, 60, 90, 120, 150 minutes
    public int DurationMinutes { get; set; }

    public StudyGroup Group { get; set; } = null!;
}
