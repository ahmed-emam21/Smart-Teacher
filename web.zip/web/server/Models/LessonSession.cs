
namespace SmartTeacher.Api.Models;

public class LessonSession
{
    public int Id { get; set; }

    public int GroupId { get; set; }
    public int? GroupScheduleId { get; set; }

    public DateTime SessionDate { get; set; }
    public TimeSpan StartTime { get; set; }
    public int DurationMinutes { get; set; }

    // Upcoming, InProgress, Postponed, Cancelled, Completed
    public string Status { get; set; } = "Upcoming";

    // Links a postponed session to its replacement session
    public int? RescheduledToSessionId { get; set; }

    public string? Notes { get; set; }
    public string? CancellationReason { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public StudyGroup Group { get; set; } = null!;
    public GroupSchedule? GroupSchedule { get; set; }
    public LessonSession? RescheduledToSession { get; set; }
}
