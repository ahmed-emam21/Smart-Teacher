namespace SmartTeacher.Api.Models;

public class Notification
{
    public int Id { get; set; }

    public string NotificationType { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public string Message { get; set; } = string.Empty;

    public string? RelatedEntityType { get; set; }
    public int? RelatedEntityId { get; set; }

    public int? CreatedByUserId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public ICollection<NotificationRecipient> Recipients { get; set; }
        = new List<NotificationRecipient>();
}