namespace SmartTeacher.Api.Models;

public class NotificationRecipient
{
    public int Id { get; set; }

    public int NotificationId { get; set; }
    public int StudentAccountId { get; set; }

    public bool IsRead { get; set; }
    public DateTime? ReadAt { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public Notification Notification { get; set; } = null!;
    public StudentAccount StudentAccount { get; set; } = null!;
}