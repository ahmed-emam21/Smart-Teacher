namespace SmartTeacher.Api.Models;

public class Payment
{
    public int Id { get; set; }

    public int StudentId { get; set; }

    public decimal Amount { get; set; }
    public DateTime PaymentDate { get; set; }

    // Cash, InstaPay, BankTransfer, EWallet, Other
    public string PaymentMethod { get; set; } = "Cash";

    public string ReceiptNumber { get; set; } = string.Empty;

    public string? Notes { get; set; }

    public int? ReceivedByUserId { get; set; }

    public bool IsCancelled { get; set; }
    public DateTime? CancelledAt { get; set; }
    public int? CancelledByUserId { get; set; }
    public string? CancellationReason { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public Student Student { get; set; } = null!;

    public ICollection<PaymentAllocation> Allocations { get; set; }
        = new List<PaymentAllocation>();
}