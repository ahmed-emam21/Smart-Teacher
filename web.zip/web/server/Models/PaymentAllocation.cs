namespace SmartTeacher.Api.Models;

public class PaymentAllocation
{
    public int Id { get; set; }

    public int PaymentId { get; set; }

    public int? DueId { get; set; }
    public int? BookSaleId { get; set; }

    public decimal AllocatedAmount { get; set; }

    // Allocation or Reversal
    public string EntryType { get; set; } = "Allocation";

    // Original allocation being reversed, if applicable
    public int? ReversesAllocationId { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public Payment Payment { get; set; } = null!;
    public PaymentAllocation? ReversesAllocation { get; set; }
}