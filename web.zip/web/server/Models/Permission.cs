namespace SmartTeacher.Api.Models;

public class Permission
{
    public int Id { get; set; }

    public string PermissionCode { get; set; } = string.Empty;
    public string PermissionName { get; set; } = string.Empty;
    public string? Description { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public ICollection<RolePermission> RolePermissions { get; set; }
        = new List<RolePermission>();
}