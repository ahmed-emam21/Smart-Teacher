namespace SmartTeacher.Api.Models;

public class Stage
{
    public int Id { get; set; }

    public string StageName { get; set; } = string.Empty;

    public int SortOrder { get; set; }

    public bool IsActive { get; set; } = true;

    public ICollection<Grade> Grades { get; set; } = new List<Grade>();
}