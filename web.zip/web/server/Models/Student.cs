namespace SmartTeacher.Api.Models;

public class Student
{
    public int Id { get; set; }

    public string StudentCode { get; set; } = string.Empty;
    public string FullName { get; set; } = string.Empty;

    public string Gender { get; set; } = string.Empty;

    public string StudentPhone { get; set; } = string.Empty;
    public string GuardianPhone { get; set; } = string.Empty;

    public string? Address { get; set; }
    public string? Notes { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public ICollection<StudentAcademicRecord> AcademicRecords { get; set; }
        = new List<StudentAcademicRecord>();
}