namespace SmartTeacher.Api.Models;

public class StudentAcademicRecord
{
    public int Id { get; set; }

    public int StudentId { get; set; }
    public int AcademicYearId { get; set; }
    public int GradeId { get; set; }

    public DateTime EnrollmentDate { get; set; }

    public bool IsArchived { get; set; }
    public DateTime? ArchivedAt { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public Student Student { get; set; } = null!;
    public AcademicYear AcademicYear { get; set; } = null!;
    public Grade Grade { get; set; } = null!;
}