namespace SmartTeacher.Api.Models;

public class StudentAccount
{
    public int Id { get; set; }

    public string Username { get; set; } = string.Empty;
    public string PasswordHash { get; set; } = string.Empty;

    // Pending / Active / Disabled
    public string Status { get; set; } = "Pending";

    public int? StudentId { get; set; }

    public DateTime? LastLoginAt { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public Student? Student { get; set; }
    public ICollection<StudentRegistrationRequest> RegistrationRequests { get; set; }
        = new List<StudentRegistrationRequest>();
}