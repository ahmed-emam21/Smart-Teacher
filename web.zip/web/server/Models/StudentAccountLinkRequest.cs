namespace SmartTeacher.Api.Models;

public class StudentAccountLinkRequest
{
    public int Id { get; set; }

    public int StudentAccountId { get; set; }
    public int StudentId { get; set; }

    // Pending / Approved / Rejected
    public string Status { get; set; } = "Pending";

    public DateTime SubmittedAt { get; set; } = DateTime.UtcNow;
    public DateTime? ReviewedAt { get; set; }
    public int? ReviewedByUserId { get; set; }

    public string? ReviewNotes { get; set; }

    public StudentAccount StudentAccount { get; set; } = null!;
    public Student Student { get; set; } = null!;
}