
namespace SmartTeacher.Api.Models;

public class StudentCreditAllocation
{
    public int Id { get; set; }

    public int CreditTransactionId { get; set; }

    public int? DueId { get; set; }
    public int? BookSaleId { get; set; }

    public decimal AllocatedAmount { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public StudentCreditTransaction CreditTransaction { get; set; } = null!;
}
