
namespace SmartTeacher.Api.Models;

public class StudentCreditTransaction
{
    public int Id { get; set; }

    public int StudentId { get; set; }
    public int? PaymentId { get; set; }

    // Add, Use, Adjustment, Refund
    public string TransactionType { get; set; } = string.Empty;

    // Always a positive amount; transaction type determines its effect
    public decimal Amount { get; set; }

    public DateTime TransactionDate { get; set; }

    public string? Notes { get; set; }

    public int? CreatedByUserId { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public Student Student { get; set; } = null!;
    public Payment? Payment { get; set; }

    public ICollection<StudentCreditAllocation> Allocations { get; set; }
        = new List<StudentCreditAllocation>();
}
