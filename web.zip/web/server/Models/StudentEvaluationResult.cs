namespace SmartTeacher.Api.Models;

public class StudentEvaluationResult
{
    public int Id { get; set; }

    public int EvaluationGroupId { get; set; }
    public int StudentGroupEnrollmentId { get; set; }

    // Taken / NotTaken / FinalAbsent
    public string Status { get; set; } = "Taken";

    public decimal? Score { get; set; }
    public string? Notes { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }

    public EvaluationGroup EvaluationGroup { get; set; } = null!;
    public StudentGroupEnrollment StudentGroupEnrollment { get; set; } = null!;
}