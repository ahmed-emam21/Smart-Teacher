
namespace SmartTeacher.Api.Models;

public class StudentGroupEnrollment
{
    public int Id { get; set; }

    public int StudentAcademicRecordId { get; set; }
    public int GroupId { get; set; }

    public DateTime StartDate { get; set; }
    public DateTime? EndDate { get; set; }

    // Active or Ended
    public string Status { get; set; } = "Active";

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public StudentAcademicRecord StudentAcademicRecord { get; set; } = null!;
    public StudyGroup Group { get; set; } = null!;
}
