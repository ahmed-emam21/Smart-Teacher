
namespace SmartTeacher.Api.Models;

public class StudentMonthlyDue
{
    public int Id { get; set; }

    public int StudentId { get; set; }
    public int AcademicYearId { get; set; }
    public int EnrollmentId { get; set; }
    public int SubscriptionId { get; set; }

    // Always the first day of the due month
    public DateTime DueMonth { get; set; }

    public decimal SubscriptionAmount { get; set; }
    public decimal DiscountAmount { get; set; }
    public decimal DueAmount { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public Student Student { get; set; } = null!;
    public AcademicYear AcademicYear { get; set; } = null!;
    public StudentGroupEnrollment Enrollment { get; set; } = null!;
    public StudentSubscription Subscription { get; set; } = null!;
}
