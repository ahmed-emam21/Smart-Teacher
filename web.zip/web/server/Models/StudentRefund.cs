namespace SmartTeacher.Api.Models;

public class StudentRefund
{
    public int Id { get; set; }

    public int StudentId { get; set; }
    public int PaymentId { get; set; }

    // Used when the refund settles a subscription due
    public int? DueId { get; set; }

    // Used when refunding unused advance credit
    public int? CreditTransactionId { get; set; }

    public decimal Amount { get; set; }

    public DateTime RefundDate { get; set; }

    public string? Reason { get; set; }

    public int? CreatedByUserId { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public Student Student { get; set; } = null!;
    public Payment Payment { get; set; } = null!;
    public StudentCreditTransaction? CreditTransaction { get; set; }
}