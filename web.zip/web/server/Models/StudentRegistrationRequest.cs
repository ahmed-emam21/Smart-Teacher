namespace SmartTeacher.Api.Models;

public class StudentRegistrationRequest
{
    public int Id { get; set; }

    public int StudentAccountId { get; set; }

    public string FullName { get; set; } = string.Empty;
    public string Gender { get; set; } = string.Empty;
    public string StudentPhone { get; set; } = string.Empty;
    public string GuardianPhone { get; set; } = string.Empty;
    public string? Address { get; set; }
    public string? Notes { get; set; }

    // Pending / Approved / Rejected
    public string Status { get; set; } = "Pending";

    public DateTime SubmittedAt { get; set; } = DateTime.UtcNow;
    public DateTime? ReviewedAt { get; set; }
    public int? ReviewedByUserId { get; set; }
    public string? ReviewNotes { get; set; }

    public StudentAccount StudentAccount { get; set; } = null!;
}