
namespace SmartTeacher.Api.Models;

public class StudentSubscription
{
    public int Id { get; set; }

    public int EnrollmentId { get; set; }

    // Snapshot of the agreed amounts
    public decimal MonthlyAmount { get; set; }
    public decimal DiscountAmount { get; set; }
    public decimal NetMonthlyAmount { get; set; }

    public DateTime StartDate { get; set; }
    public DateTime? EndDate { get; set; }

    // Active or Ended
    public string Status { get; set; } = "Active";

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public StudentGroupEnrollment Enrollment { get; set; } = null!;
}
