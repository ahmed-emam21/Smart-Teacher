
namespace SmartTeacher.Api.Models;

public class StudyGroup
{
    public int Id { get; set; }

    public int AcademicYearId { get; set; }
    public int GradeId { get; set; }

    public string GroupName { get; set; } = string.Empty;
    public int MaxStudents { get; set; }

    public bool IsArchived { get; set; }
    public DateTime? ArchivedAt { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public AcademicYear AcademicYear { get; set; } = null!;
    public Grade Grade { get; set; } = null!;

    public ICollection<GroupSchedule> Schedules { get; set; }
        = new List<GroupSchedule>();
}
