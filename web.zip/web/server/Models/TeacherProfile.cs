namespace SmartTeacher.Api.Models;

public class TeacherProfile
{
    public int Id { get; set; }

    public string TeacherName { get; set; } = string.Empty;
    public string SubjectName { get; set; } = string.Empty;
    public string? CenterName { get; set; }

    public string? Phone { get; set; }
    public string? Address { get; set; }
    public string? LogoPath { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}