
using Microsoft.EntityFrameworkCore;
using SmartTeacher.Api.Data;

var builder = WebApplication.CreateBuilder(args);

// إعداد الاتصال بقاعدة بيانات MySQL
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");

builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseMySql(
        connectionString,
        new MySqlServerVersion(new Version(8, 4, 13))
    )
);

// الخدمات الافتراضية
builder.Services.AddOpenApi();

var app = builder.Build();

// إعداد OpenAPI
if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
}

app.UseHttpsRedirection();

// اختبار تشغيل التطبيق
app.MapGet("/", () => "Smart Teacher API is running");

app.MapGet("/test-database", async (AppDbContext db) =>
{
    try
    {
        bool connected = await db.Database.CanConnectAsync();

        return Results.Ok(new
        {
            Success = connected,
            Message = connected
                ? "Connected to MySQL successfully"
                : "Could not connect to MySQL"
        });
    }
        catch (Exception ex)
    {
        return Results.Problem(ex.Message);
    }
});
app.Run();
